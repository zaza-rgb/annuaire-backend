<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = ['code'];

    public function translations()
    {
        return $this->hasMany(CategoryTranslation::class);
    }

    public function businesses()
    {
        return $this->hasMany(Business::class);
    }
}